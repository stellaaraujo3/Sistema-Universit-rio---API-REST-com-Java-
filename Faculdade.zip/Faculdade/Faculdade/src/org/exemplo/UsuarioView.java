package org.exemplo;

import java.util.List;
import java.util.Scanner;

public class UsuarioView {
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    private Scanner scanner = new Scanner(System.in);

    // Exibe o menu de gerenciamento de usuários
    public void exibirMenu() {
        int opcao = -1;

        while (opcao != 5) {
            System.out.println("\nGerenciamento de Usuários");
            System.out.println("1. Cadastrar Usuário");
            System.out.println("2. Listar Usuários");
            System.out.println("3. Atualizar Usuário");
            System.out.println("4. Remover Usuário");
            System.out.println("5. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> cadastrarUsuario();
                case 2 -> listarUsuarios();
                case 3 -> atualizarUsuario();
                case 4 -> removerUsuario();
                case 5 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        }
    }

    // Cadastra um novo usuário no sistema
    private void cadastrarUsuario() {
        System.out.print("Usuário (login): ");
        String usuario = scanner.nextLine();

        System.out.print("Senha: ");
        String senha = scanner.nextLine();

        System.out.print("Tipo (usuario/adm): ");
        String tipo = scanner.nextLine().trim().toLowerCase();
        if (!tipo.equals("usuario") && !tipo.equals("adm")) {
            System.out.println("Tipo inválido. Use 'usuario' ou 'adm'.");
            return;
        }

        Integer alunomatricula = null;
        if (tipo.equals("usuario")) {
            System.out.print("Matrícula do aluno: ");
            String entrada = scanner.nextLine();
            if (!entrada.isBlank()) {
                try {
                    alunomatricula = Integer.parseInt(entrada);
                } catch (NumberFormatException e) {
                    System.out.println("Matrícula inválida. Deve ser um número inteiro.");
                    return;
                }
            }
        }

        Usuario u = new Usuario(usuario, senha, tipo, alunomatricula);
        usuarioDAO.adicionarUsuario(u);
    }

    // Lista todos os usuários cadastrados
    private void listarUsuarios() {
        List<Usuario> usuarios = usuarioDAO.listarUsuarios();
        System.out.println("\nLista de Usuários");
        for (Usuario u : usuarios) {
            System.out.println(u);
        }
    }

    // Atualiza os dados de um usuário
    private void atualizarUsuario() {
        System.out.print("ID do usuário a atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Novo Usuário (login): ");
        String usuario = scanner.nextLine();

        System.out.print("Nova Senha: ");
        String senha = scanner.nextLine();

        System.out.print("Novo Tipo (usuario/adm): ");
        String tipo = scanner.nextLine().trim().toLowerCase();
        if (!tipo.equals("usuario") && !tipo.equals("adm")) {
            System.out.println("Tipo inválido. Use 'usuario' ou 'adm'.");
            return;
        }

        int alunomatricula = 0;
        if (tipo.equals("usuario")) {
            System.out.print("Nova Matrícula do aluno: ");
            alunomatricula = scanner.nextInt();
            scanner.nextLine();
        } else {
            alunomatricula = 0;
        }

        Usuario u = new Usuario(id, usuario, senha, tipo, alunomatricula);
        usuarioDAO.atualizarUsuario(u);
    }

    // Remove um usuário pelo ID
    private void removerUsuario() {
        System.out.print("ID do usuário a remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        usuarioDAO.removerUsuario(id);
        System.out.println("Usuário removido com sucesso!");
    }
}
